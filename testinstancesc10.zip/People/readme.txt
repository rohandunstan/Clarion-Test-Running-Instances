This is an example of how to implement simple licence control in the Ip Server data dll.

It demonstrates validating against an expiry date and licensing a number of concurrent users.

This is not a complete licence solution.

Requires IP Server/Ip Client.

The app is an original SV supplied people.app for ip driver

The code used to check the number of logged in users was published by ;

2011-08-26 -- Jens Matschke Par2: How to detect if an exe is running 

The article is available on icetips at https://www.icetips.com/showarticle.php?articleid=1539

Jens' code could be useful in an Appbroker, Ip Server or Terminal Services based app. 

rohan@etouchos.com
